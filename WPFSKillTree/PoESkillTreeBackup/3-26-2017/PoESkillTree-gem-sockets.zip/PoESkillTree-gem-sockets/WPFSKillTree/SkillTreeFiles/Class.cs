namespace POESKillTree.SkillTreeFiles
{
    public class Class
    {
        public int Order;
        public string Name;
        public string DisplayName;
        public string FlavourText;
        public Vector2D FlavourTextRect;
        public int[] FlavourTextColour;
    }
}