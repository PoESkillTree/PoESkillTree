﻿namespace POESKillTree.Model.Items.Enums
{
    public enum ModType
    {
        Prefix,
        Suffix
    }
}