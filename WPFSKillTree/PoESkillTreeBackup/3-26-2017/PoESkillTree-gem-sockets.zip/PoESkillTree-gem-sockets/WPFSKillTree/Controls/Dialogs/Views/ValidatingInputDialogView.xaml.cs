﻿namespace POESKillTree.Controls.Dialogs.Views
{
    /// <summary>
    /// Interaction logic for ValidatingInputDialogView.xaml
    /// </summary>
    public partial class ValidatingInputDialogView
    {
        public ValidatingInputDialogView()
        {
            InitializeComponent();
        }
    }
}
