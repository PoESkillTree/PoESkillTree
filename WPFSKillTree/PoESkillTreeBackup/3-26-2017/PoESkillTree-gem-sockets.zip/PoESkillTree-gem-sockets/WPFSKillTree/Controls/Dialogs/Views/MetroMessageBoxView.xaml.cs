namespace POESKillTree.Controls.Dialogs.Views
{
    /// <summary>
    /// Interaction logic for MetroMessageView.xaml
    /// </summary>
    public partial class MetroMessageBoxView
    {
        public MetroMessageBoxView()
        {
            InitializeComponent();
        }
    }
}
