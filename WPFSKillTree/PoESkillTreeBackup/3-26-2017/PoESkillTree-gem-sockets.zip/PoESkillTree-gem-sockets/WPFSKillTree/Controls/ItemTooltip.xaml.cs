﻿namespace POESKillTree.Controls
{
    /// <summary>
    /// Interaction logic for Item.xaml
    /// </summary>
    public partial class ItemTooltip
    {
        public ItemTooltip()
        {
            InitializeComponent();
        }
    }
}
