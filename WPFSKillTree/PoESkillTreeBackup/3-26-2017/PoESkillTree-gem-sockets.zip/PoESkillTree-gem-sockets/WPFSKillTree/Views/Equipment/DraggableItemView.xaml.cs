﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for DraggableItemView.xaml
    /// </summary>
    public partial class DraggableItemView
    {
        public DraggableItemView()
        {
            InitializeComponent();
        }
    }
}
