﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for InventoryItemView.xaml
    /// </summary>
    public partial class InventoryItemView
    {
        public InventoryItemView()
        {
            InitializeComponent();
        }
    }
}
