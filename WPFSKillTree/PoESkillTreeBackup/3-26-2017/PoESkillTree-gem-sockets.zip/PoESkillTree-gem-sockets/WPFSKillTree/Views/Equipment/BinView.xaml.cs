﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for BinView.xaml
    /// </summary>
    public partial class BinView
    {
        public BinView()
        {
            InitializeComponent();
        }
    }
}
