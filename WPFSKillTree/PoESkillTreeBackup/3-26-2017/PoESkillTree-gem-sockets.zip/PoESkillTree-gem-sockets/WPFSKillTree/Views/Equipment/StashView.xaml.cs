﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for StashView.xaml
    /// </summary>
    public partial class StashView
    {
        public StashView()
        {
            InitializeComponent();
        }
    }
}
