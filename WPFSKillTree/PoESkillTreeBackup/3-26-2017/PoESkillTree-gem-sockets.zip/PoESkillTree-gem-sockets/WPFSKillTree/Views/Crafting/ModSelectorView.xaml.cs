﻿namespace POESKillTree.Views.Crafting
{
    /// <summary>
    /// Interaction logic for ModSelectorView.xaml
    /// </summary>
    public partial class ModSelectorView
    {
        public ModSelectorView()
        {
            InitializeComponent();
        }
    }
}
