﻿namespace POESKillTree.Views.Crafting
{
    /// <summary>
    /// Interaction logic for SliderGroupView.xaml
    /// </summary>
    public partial class SliderGroupView
    {
        public SliderGroupView()
        {
            InitializeComponent();
        }
    }
}
