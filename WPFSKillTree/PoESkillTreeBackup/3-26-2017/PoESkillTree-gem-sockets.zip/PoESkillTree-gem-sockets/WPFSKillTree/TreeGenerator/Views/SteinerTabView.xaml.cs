﻿namespace POESKillTree.TreeGenerator.Views
{
    /// <summary>
    /// Interaction logic for SteinerTabView.xaml
    /// </summary>
    public partial class SteinerTabView
    {
        public SteinerTabView()
        {
            InitializeComponent();
        }
    }
}
