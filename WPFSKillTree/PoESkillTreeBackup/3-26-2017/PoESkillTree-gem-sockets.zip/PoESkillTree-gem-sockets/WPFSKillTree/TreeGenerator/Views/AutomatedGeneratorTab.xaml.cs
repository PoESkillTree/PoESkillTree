﻿namespace POESKillTree.TreeGenerator.Views
{
    /// <summary>
    /// Interaction logic for GeneratorSettingsTab.xaml
    /// </summary>
    public partial class AutomatedGeneratorTab
    {
        public AutomatedGeneratorTab()
        {
            InitializeComponent();
        }
    }
}
