﻿namespace POESKillTree.TreeGenerator.Views
{
    /// <summary>
    /// Interaction logic for ControllerWindow.xaml
    /// </summary>
    public partial class ControllerWindow
    {
        public ControllerWindow()
        {
            InitializeComponent();
        }
    }
}
