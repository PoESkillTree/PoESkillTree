﻿using System;
using CSharpGlobalCode.GlobalCode_ExperimentalCode;

namespace POESKillTree.TreeGenerator.Settings
{
    struct XAMLConstants
    {
        static readonly SmallDec One = 1;
        static readonly SmallDec OneHundreth = "0.01";
    }
}
