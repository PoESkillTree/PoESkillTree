﻿Extended WPF Toolkit styles for use with Metro MahApps

Original source: https://monotone.codeplex.com/

DON'T USE ORIGINAL UNMODIFIED XAML SOURCE FILE!
