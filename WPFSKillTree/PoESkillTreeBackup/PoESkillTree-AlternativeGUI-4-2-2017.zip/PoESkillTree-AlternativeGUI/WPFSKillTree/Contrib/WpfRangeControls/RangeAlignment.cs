﻿namespace WpfRangeControls
{
    public enum RangeAlignment
    {
        Begin,
        End,
        Center
    }
}