﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for SocketedGemsEditingView.xaml
    /// </summary>
    public partial class SocketedGemsEditingView
    {
        public SocketedGemsEditingView()
        {
            InitializeComponent();
        }
    }
}
