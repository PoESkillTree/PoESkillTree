﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for StashItemView.xaml
    /// </summary>
    public partial class StashItemView
    {
        public StashItemView()
        {
            InitializeComponent();
        }
    }
}
