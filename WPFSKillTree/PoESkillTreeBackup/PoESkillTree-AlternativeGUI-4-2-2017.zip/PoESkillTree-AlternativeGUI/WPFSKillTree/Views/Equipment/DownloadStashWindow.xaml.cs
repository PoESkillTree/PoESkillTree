﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for DownloadItemsWindow.xaml
    /// </summary>
    public partial class DownloadStashWindow
    {
        public DownloadStashWindow()
        {
            InitializeComponent();
        }
    }
}
