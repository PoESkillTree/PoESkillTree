﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for TabPicker.xaml
    /// </summary>
    public partial class TabPicker
    {
        public TabPicker()
        {
            InitializeComponent();
        }
    }
}
