﻿namespace POESKillTree.Views.Equipment
{
    /// <summary>
    /// Interaction logic for InventoryView.xaml
    /// </summary>
    public partial class InventoryView
    {
        public InventoryView()
        {
            InitializeComponent();
        }
    }
}
