﻿namespace POESKillTree.Views
{
    /// <summary>
    /// Interaction logic for SettingsMenuWindow.xaml
    /// </summary>
    public partial class SettingsMenuWindow
    {
        public SettingsMenuWindow()
        {
            InitializeComponent();
        }
    }
}
