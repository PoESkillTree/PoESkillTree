﻿namespace POESKillTree.Views.Builds
{
    /// <summary>
    /// Interaction logic for BuildsControl.xaml
    /// </summary>
    public partial class BuildsControl
    {
        public BuildsControl()
        {
            InitializeComponent();
        }
    }
}
