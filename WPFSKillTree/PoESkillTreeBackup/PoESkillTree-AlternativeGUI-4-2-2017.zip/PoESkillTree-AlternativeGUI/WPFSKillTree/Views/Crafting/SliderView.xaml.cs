﻿namespace POESKillTree.Views.Crafting
{
    /// <summary>
    /// Interaction logic for SliderView.xaml
    /// </summary>
    public partial class SliderView
    {
        public SliderView()
        {
            InitializeComponent();
        }
    }
}
