﻿namespace POESKillTree.Views.Crafting
{
    /// <summary>
    /// Interaction logic for UniqueCraftingView.xaml
    /// </summary>
    public partial class UniqueCraftingView
    {
        public UniqueCraftingView()
        {
            InitializeComponent();
        }
    }
}
