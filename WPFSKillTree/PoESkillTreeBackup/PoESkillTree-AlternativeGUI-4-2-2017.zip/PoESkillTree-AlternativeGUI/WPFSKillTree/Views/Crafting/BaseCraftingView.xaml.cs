﻿namespace POESKillTree.Views.Crafting
{
    /// <summary>
    /// Interaction logic for BaseCraftingView.xaml
    /// </summary>
    public partial class BaseCraftingView
    {
        public BaseCraftingView()
        {
            InitializeComponent();
        }
    }
}
