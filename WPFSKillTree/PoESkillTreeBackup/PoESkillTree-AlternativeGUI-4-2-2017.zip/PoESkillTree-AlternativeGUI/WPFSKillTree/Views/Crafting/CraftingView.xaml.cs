﻿namespace POESKillTree.Views.Crafting
{
    /// <summary>
    /// Interaction logic for CraftingView.xaml
    /// </summary>
    public partial class CraftingView
    {
        public CraftingView()
        {
            InitializeComponent();
        }
    }
}
