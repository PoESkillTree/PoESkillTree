﻿namespace POESKillTree.Views
{
    public partial class AboutWindow
    {
        public AboutWindow()
        {
            InitializeComponent();
        }
    }
}
