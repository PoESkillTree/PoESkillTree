﻿namespace POESKillTree.Views
{
    /// <summary>
    /// Interaction logic for DownloadItemsWindow.xaml
    /// </summary>
    public partial class HotkeysWindow
    {
        public HotkeysWindow()
        {
            InitializeComponent();
        }
    }
}
