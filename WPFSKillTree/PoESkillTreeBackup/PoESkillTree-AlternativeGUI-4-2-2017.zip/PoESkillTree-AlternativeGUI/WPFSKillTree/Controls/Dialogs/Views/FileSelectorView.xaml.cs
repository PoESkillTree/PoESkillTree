﻿namespace POESKillTree.Controls.Dialogs.Views
{
    /// <summary>
    /// Interaction logic for FileSelectorView.xaml
    /// </summary>
    public partial class FileSelectorView
    {
        public FileSelectorView()
        {
            InitializeComponent();
        }
    }
}
