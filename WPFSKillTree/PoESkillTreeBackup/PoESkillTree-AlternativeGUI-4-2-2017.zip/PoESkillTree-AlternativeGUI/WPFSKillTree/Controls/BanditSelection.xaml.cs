﻿namespace POESKillTree.Controls
{
    /// <summary>
    /// Interaction logic for BanditSelection.xaml
    /// </summary>
    public partial class BanditSelection
    {
        public BanditSelection()
        {
            InitializeComponent();
        }
    }
}
